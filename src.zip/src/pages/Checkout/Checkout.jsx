import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { addDoc, collection, serverTimestamp } from 'firebase/firestore'
import { db } from '../../firebase/config'
import { useAuth } from '../../context/AuthContext'
import { useCart } from '../../context/CartContext'
import EmptyState from '../../components/EmptyState/EmptyState.jsx'
import styles from './Checkout.module.css'

export default function Checkout() {
  const [nombre, setNombre] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState(null)
  const [orderId, setOrderId] = useState(null)
  const { user } = useAuth()
  const { cart, totalPrice, clear } = useCart()
  const navigate = useNavigate()

  const handlePurchase = async (event) => {
    event.preventDefault()
    setIsProcessing(true)
    setError(null)

    try {
      const order = {
        userId: user.uid,
        userEmail: user.email,
        buyer: { nombre },
        items: cart.map((item) => ({
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity
        })),
        total: totalPrice,
        createdAt: serverTimestamp()
      }

      const docRef = await addDoc(collection(db, 'orders'), order)
      setOrderId(docRef.id)
      clear()
    } catch (err) {
      setError('No pudimos generar tu orden. Intentá de nuevo.')
    } finally {
      setIsProcessing(false)
    }
  }

  if (orderId) {
    return (
      <div className={styles.successContainer}>
        <h2 className={styles.successTitle}>¡Compra confirmada!</h2>
        <p className={styles.successText}>
          Tu número de orden es <strong>{orderId}</strong>. Guardalo como comprobante.
        </p>
        <button className={styles.successButton} onClick={() => navigate('/')}>
          Volver al inicio
        </button>
      </div>
    )
  }

  if (cart.length === 0) {
    return (
      <EmptyState
        emoji="🛍️"
        title="Todavía no elegiste nada"
        text="Agregá algún mate, bombilla o accesorio al carrito antes de pasar a confirmar tu compra."
        ctaText="Ver catálogo"
        ctaTo="/productos"
      />
    )
  }

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Finalizar Compra</h1>
      <form onSubmit={handlePurchase}>
        <div className={styles.field}>
          <label className={styles.label}>Nombre completo:</label>
          <input
            type="text"
            required
            disabled={isProcessing}
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            className={styles.input}
          />
        </div>

        {error && <p className={styles.error}>{error}</p>}

        <button
          type="submit"
          disabled={isProcessing}
          className={styles.submitButton}
        >
          {isProcessing && <span className={styles.spinner} />}
          {isProcessing ? 'Procesando...' : 'Confirmar compra'}
        </button>
      </form>

      <button className={styles.cancelButton} onClick={() => navigate(-1)}>
        Cancelar y volver atrás
      </button>
    </div>
  )
}