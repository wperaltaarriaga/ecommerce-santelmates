import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import styles from './AuthWidget.module.css'

function AuthWidget() {
  const { user, logout } = useAuth()
  const [abierto, setAbierto] = useState(false)
  const wrapperRef = useRef(null)

  useEffect(() => {
    const cerrarSiEsAfuera = (e) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) setAbierto(false)
    }
    document.addEventListener('mousedown', cerrarSiEsAfuera)
    return () => document.removeEventListener('mousedown', cerrarSiEsAfuera)
  }, [])

  const handleLogout = () => {
    logout()
    setAbierto(false)
  }

  return (
    <div className={styles.wrapper} ref={wrapperRef}>
      <button
        className={styles.iconButton}
        onClick={() => setAbierto((prev) => !prev)}
        aria-label="Cuenta"
      >
        👤
      </button>

      {abierto && (
        <div className={styles.dropdown}>
          {user ? (
            <>
              <p className={styles.email}>{user.email}</p>
              <button className={styles.logoutButton} onClick={handleLogout}>
                Cerrar sesión
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className={styles.dropdownLink} onClick={() => setAbierto(false)}>
                Iniciar sesión
              </Link>
              <Link to="/register" className={styles.dropdownLink} onClick={() => setAbierto(false)}>
                Registrarme
              </Link>
            </>
          )}
        </div>
      )}
    </div>
  )
}

export default AuthWidget