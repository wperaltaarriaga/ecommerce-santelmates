import { useState } from 'react'
import { Routes, Route } from 'react-router-dom'
import './App.css'
//components
import ItemListContainer from './components/ItemListContainer/ItemListContainer'
import ItemDetailContainer from './components/ItemDetailContainer/ItemDetailContainer'
//pages
import NotFound from './pages/NotFound/NotFound.jsx'
import NavBar from './components/NavBar/NavBar'
import Home from './pages/Home'
import Checkout from './pages/Checkout/Checkout'


function App() {
  const [categoriaActiva, setCategoriaActiva] = useState(null)
  const [busqueda, setBusqueda] = useState('')

  return (
    <>
      <NavBar
        categoriaActiva={categoriaActiva}
        setCategoriaActiva={setCategoriaActiva}
        busqueda={busqueda}
        setBusqueda={setBusqueda}
      />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route
          path="/productos"
          element={
            <ItemListContainer
              categoriaActiva={categoriaActiva}
              busqueda={busqueda}
            />
          }
        />
        <Route path="/detalle/:id" element={<ItemDetailContainer />} />
        <Route path="*" element={<NotFound />} />
        <Route path="/checkout" element={<Checkout />} />
      </Routes>
    </>
  )
}

export default App